from telethon import TelegramClient

api_id = 14847906
api_hash = "e4c8bab588782253015a20da73354980"
bot_token = "5563306050:AAHoz7AFwlzvqVJ3i6NTfe6_cUMR53ZP3Ug"
client = TelegramClient('alohidasnsnjsdark', api_id, api_hash)

botClient = TelegramClient('Magicbot_uz_bot', api_id, api_hash).start(bot_token=bot_token)